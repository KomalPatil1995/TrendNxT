package assignment6;

public class FinalMethodTest {
public static void main(String[] args) {
	FinalDemo f1= new FinalDemo();
	f1= new FinalDemo();
	f1= new FinalDemo();
	
}
}
