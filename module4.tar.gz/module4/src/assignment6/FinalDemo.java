package assignment6;

public class FinalDemo {
 public final void Test() {
	 System.out.println("Finalize method called");
 }
}
