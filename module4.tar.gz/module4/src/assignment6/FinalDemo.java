package assignment6;

public class FinalDemo {
 
 public void finalize() 
 { 
     System.out.println("Finalize method called");
 } 
}
