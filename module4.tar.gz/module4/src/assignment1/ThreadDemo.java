package assignment1;

public class ThreadDemo {
	public static int rand=0;
	public static void main(String[] args) {
		Thread1 t1= new Thread1("thread1");
		t1.start();
		
	
		Thread2 t2= new Thread2("Thread2");
		t2.start();
		for(int i=0;i<5;i++) {
			t1.run();
			t2.run();
		}
	
	
		
	}
	
}
