package assignment2;

public class argumentDemo {
public static void main(String[] args) {
	if(args!= null) {
		String companyName=args[0] + " " +args[1];
		if(companyName.equals("Wipro Bangalore")) {
			System.out.println("“Wipro Technologies Bangalore");
		}else if(companyName.equals("ABC Mumbai")) {System.out.println("ABC Technologies Mumbai");}
		else {
			System.out.println("wrong input");
		}
		
	}
	
}
}
