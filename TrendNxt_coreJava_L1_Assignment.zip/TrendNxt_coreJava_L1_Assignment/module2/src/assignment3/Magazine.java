package assignment3;

public class Magazine extends Book{
	String type;
	Magazine(String isbn, String title, String type, int price) {
		super(isbn, title, price);
		this.type=type;
		// TODO Auto-generated constructor stub
	}
	 public void displayDetails() {
		 super.displayDetails();
		 System.out.println(" Type of magazine is "+this.type);
	 }



}
