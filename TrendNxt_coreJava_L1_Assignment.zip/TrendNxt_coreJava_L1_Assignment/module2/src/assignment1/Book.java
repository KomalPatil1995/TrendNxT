package assignment1;
public class Book {
	public String isbn;
	public String title;
	public String author;
	public int price;
 Book(String isbn, String title, String author, int price){
		this.isbn=isbn;
		this.title=title;
		this.author=author;
		this.price=price;
		
	}
 public void displayDetails() {
	 System.out.println("isbn: "+this.isbn +", Book Title :"+this.title+", Book author :"+this.author+", price :"+this.price);
	 
 }
 public float discountedPrice(float discount) {
	 float priceToPay=((100-discount)/100)*this.price;
	 return priceToPay;
	 
 }

	public static void main(String[] args) {
		
		Book b1= new Book("123456789","something","nothing",500);
		Book b2= new Book("123456793435","something1","nothing1",550);
		Book b3= new Book("3456789","something2","nothing2",600);
		b1.displayDetails();
		b2.displayDetails();
		b3.displayDetails();
		System.out.println("price to pay after discount on book "+b1.title+ " is "+ b1.discountedPrice(10));
		

}
	
}
