/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author komalpatil
 */
class cashPayment extends Payment
{
    void paymentDetails()
    {
        super.paymentDetails();
        System.out.println("The payment is in cash");
    }
}
