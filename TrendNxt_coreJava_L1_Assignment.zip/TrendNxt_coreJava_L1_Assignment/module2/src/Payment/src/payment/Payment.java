/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author komalpatil
 */
class Payment {

	private	double amt;
	public void set(double b)
		{
		    amt=b;
		}
	public double get()
	{
	    return amt;
	}
	void paymentDetails()
	{
	    System.out.println("The amount is "+amt);
	}
}