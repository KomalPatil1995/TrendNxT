/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author komalpatil
 */
class CreditCardPayment extends Payment
{
    String name;
    String exp;
    String no;
    double am;
    CreditCardPayment(String n, String e, String nn)
    {
        name=n;
        exp=e;
        no=nn;
    }

    void paymentDetails()
    {
        
        super.paymentDetails();
        System.out.println("The name is="+ name);
        System.out.println("The exp is="+ exp);
        System.out.println("The no is="+ no);
    }
}