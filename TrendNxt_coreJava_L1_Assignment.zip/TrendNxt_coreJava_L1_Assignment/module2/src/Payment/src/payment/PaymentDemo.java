/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author komalpatil
 */
public class PaymentDemo {
    public static void main(String args[])
    {
        
        
        Payment c=new cashPayment();
        c.set(150);
        c.paymentDetails();
      System.out.println();
        Payment ob=new CreditCardPayment("xyz","12/08/2022","12345678");
        ob.set(1000);
        ob.paymentDetails();
        System.out.println();
        Payment ob2=new CreditCardPayment("abc","13/08/2025","87654321");
        ob2.set(2000);
        ob2.paymentDetails();
        
    }
    
}
