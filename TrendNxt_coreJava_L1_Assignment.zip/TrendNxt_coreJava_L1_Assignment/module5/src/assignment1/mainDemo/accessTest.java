package assignment1.mainDemo;

import assignment1.test.foundation;
// only Var4 is accesssible beacuse its having public access specifier
public class accessTest {
public static void main(String[] args) {
	foundation s=new foundation();
int val1=s.var1;
 int val2=s.var2;
int val3=s.var3;
 int val4=s.var4;

}
	
}
