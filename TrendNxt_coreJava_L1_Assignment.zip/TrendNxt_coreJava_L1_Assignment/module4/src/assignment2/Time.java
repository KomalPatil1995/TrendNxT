package assignment2;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Time {
	public static void main(String... args) throws InterruptedException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        int i=0;
        while(i<11) {
        	i++;
            System.out.printf("\r%s", sdf.format(new Date()));
            Thread.sleep(2000);
        }
	}
}
