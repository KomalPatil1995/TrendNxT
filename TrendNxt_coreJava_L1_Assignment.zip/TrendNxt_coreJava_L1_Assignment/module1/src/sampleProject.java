import java.util.Scanner;

public class sampleProject {
	public static void main(String[] args) {
		System.out.println("<><><><>Topic 1:<><><><>");
		/////////////////////////////Asssignment1 /////////////////////////////////////
		System.out.println("****************Assignment 1:****************");
		String name= "Komal Dinkar Patil";
		System.out.println("Welcome to Java Programming");
		System.out.println(name);
		/////////////////////////////Asssignment2 /////////////////////////////////////
		System.out.println("****************Assignment 2 :****************");
		int a=5;
		int b=8;
		int c=6;
		int d=55;
		int e=9;
		int f=20;
		int g=3;
		int h=15;
		int i=2;
		System.out.println(" -5 + 8 * 6 ="+ (-a+b*c));
		System.out.println("(55+9) % 9 ="+((d+e)%e));
		System.out.println("20 + -3*5 / 8 ="+(f+(-g)*a/b));
		System.out.println(" 5 + 15 / 3 * 2 -8 % 3 ="+(a+h/g*i-b%g));
		/////////////////////////////Asssignment3 /////////////////////////////////////
		System.out.println("****************Assignment 3:****************");
		 double minutesInYear = 60 * 24 * 365;

	        Scanner input = new Scanner(System.in);

	        System.out.print("Input the number of minutes: ");

	        double min = input.nextDouble();

	        long years = (long) (min / minutesInYear);
	        int days = (int) (min / 60 / 24) % 365;

	        System.out.println((int) min + " minutes is approximately " + years + " years and " + days + " days");
	        //////////////Assignment
			/////////////////////////////Asssignment4 /////////////////////////////////////
	        System.out.println("*****************Assignment 4:*******************");
	  
	        System.out.println("input the Month Number");
	        int mon=input.nextInt();
	        String monthName="";
	        switch(mon)
	        {
	        case 1: monthName="January";
	        break;
	        case 2: monthName="february";
	        break;
	        case 3: monthName="March";
	        break;
	        case 4: monthName="April";
	        break;
	        case 5: monthName="May";
	        break;
	        case 6: monthName="June";
	        break;
	        case 7: monthName="July";
	        break;
	        case 8: monthName="August";
	        break;
	        case 9: monthName="September";
	        break;
	        case 10: monthName="October";
	        break;
	        case 11: monthName="November";
	        break;
	        case 12: monthName="December";
	        break;
	        default: System.out.println("enter value between 1 to 12 only");
	        break;
	        
	        }
	        System.out.println("Month Name:"+monthName);
	      
			/////////////////////////////Asssignment5 /////////////////////////////////////
	        System.out.println("*****************Assignment 5:*******************");
	        System.out.println("Enter 4-digit Number :");
	        int num=input.nextInt();
	        int sum=0;
	        
	        while(num>0)
	        {
	        	sum+=num%10;
	        	num/=10;
	        }
	        System.out.println("sum ="+sum);
	}

}
