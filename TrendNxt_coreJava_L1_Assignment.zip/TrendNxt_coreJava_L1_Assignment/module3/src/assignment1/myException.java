package assignment1;

public class myException extends Exception {
public String toString() {
	
	return ("age entered must be >=18 and < 60");
	
}
}
