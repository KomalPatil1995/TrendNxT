package assignment2;

public class NumberException {
	public static void main(String[] args) {
		if(args.length >0) {
			for(int i=0;i<2;i++) {
				int j=4*i;
				try {
					int s1= Integer.parseInt(args[j+1]);
					int s2= Integer.parseInt(args[j+2]);
					int s3= Integer.parseInt(args[j+3]);
				}
				catch(NumberFormatException e) {
					System.out.println(e);
					
				}
			}
			
			}
	
	}
}
