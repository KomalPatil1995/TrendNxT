package assignment1;

class Thread2 implements Runnable {
	   private Thread t;
	   private String threadName;
	   
	   Thread2( String name) {
	      threadName = name;
	      System.out.println("Creating " +  threadName );
	   }
	   
	   public void run() {
		   int fact=1;
		   double number= ThreadDemo.rand;
		   for(int i=1;i<=number;i++){    
			      fact=fact*i;    
			  } 
		   System.out.println("Factorial of "+number+" : "+fact);
	   }
	   
	   public void start () {
	      System.out.println("Starting " +  threadName );
	      if (t == null) {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }
	}
