package live;
import music.string.Veena;
import music.wind.saxophone;
import music.Playable;
public class Test {
	public static void main(String[] args) {
	Veena v1= new Veena();
	saxophone s1= new saxophone();
	v1.play();
	s1.play();
	Playable p1= new Veena();
	p1.play();
	
	}
}
